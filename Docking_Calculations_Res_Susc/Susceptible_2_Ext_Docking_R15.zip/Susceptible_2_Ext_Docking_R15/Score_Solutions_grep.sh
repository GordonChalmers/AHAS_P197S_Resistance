for file in $(ls gold_soln*);
	do grep -A 1 "> <Gold.PLP.Fitness" $file | grep -v "<Gold.PLP.Fitness>" >> score_list.txt
done
